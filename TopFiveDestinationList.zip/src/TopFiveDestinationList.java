
import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;

public class TopFiveDestinationList {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            TopDestinationListFrame topDestinationListFrame = new TopDestinationListFrame();
            topDestinationListFrame.setTitle("Top 5 Destination List");
            topDestinationListFrame.setVisible(true);
        });
    }
}

class TopDestinationListFrame extends JFrame {
    private DefaultListModel<TextAndIcon> listModel;

    public TopDestinationListFrame() {
        super("Top Five Destination List");

        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setSize(900, 750);
        setLocationRelativeTo(null);

        listModel = new DefaultListModel<>();

        addDestination("1. Bora Bora, French Polynesia", "Crystal-clear waters and overwater bungalows in paradise.", "/resources/borabora.jpg", "https://snhutravel.com/packages/borabora");
        addDestination("2. Rome, Italy", "Historic sites, cobblestone streets, and delicious Italian cuisine.", "/resources/rome.jpg", "https://snhutravel.com/packages/rome");
        addDestination("3. Maldives", "Relax on stunning white sand beaches in the Indian Ocean.", "/resources/maldives.jpg", "https://snhutravel.com/packages/maldives");
        addDestination("4. Dubai, UAE", "Explore luxury shopping, modern architecture, and desert adventures.", "/resources/dubai.jpg", "https://snhutravel.com/packages/dubai");
        addDestination("5. Switzerland", "Breathtaking alpine scenery and charming mountain villages.", "/resources/switzerland.jpg", "https://snhutravel.com/packages/switzerland");

        JList<TextAndIcon> list = new JList<>(listModel);
        JScrollPane scrollPane = new JScrollPane(list);
        TextAndIconListCellRenderer renderer = new TextAndIconListCellRenderer(10);
        list.setCellRenderer(renderer);
        getContentPane().add(scrollPane, BorderLayout.CENTER);
    }

    private void addDestination(String title, String description, String imagePath, String linkURL) {
        String htmlText = "<html><b>" + title + "</b><br>" + description +
                          "<br><a href='" + linkURL + "'>View top-selling package</a></html>";
        ImageIcon icon = new ImageIcon(getClass().getResource(imagePath));
        TextAndIcon tai = new TextAndIcon(htmlText, icon);
        listModel.addElement(tai);
    }
}

class TextAndIcon {
    private String text;
    private Icon icon;

    public TextAndIcon(String text, Icon icon) {
        this.text = text;
        this.icon = icon;
    }

    public String getText() {
        return text;
    }

    public Icon getIcon() {
        return icon;
    }

    public void setText(String text) {
        this.text = text;
    }

    public void setIcon(Icon icon) {
        this.icon = icon;
    }
}

class TextAndIconListCellRenderer extends JLabel implements ListCellRenderer<TextAndIcon> {
    private static final Border NO_FOCUS_BORDER = new EmptyBorder(1, 1, 1, 1);
    private Border insideBorder;

    public TextAndIconListCellRenderer() {
        this(5, 5, 5, 5);
    }

    public TextAndIconListCellRenderer(int top, int right, int bottom, int left) {
        insideBorder = BorderFactory.createEmptyBorder(top, left, bottom, right);
        setOpaque(true);
    }

    @Override
    public Component getListCellRendererComponent(JList<? extends TextAndIcon> list, TextAndIcon value,
                                                  int index, boolean isSelected, boolean cellHasFocus) {
        setText(value.getText());
        setIcon(value.getIcon());

        if (isSelected) {
            setBackground(list.getSelectionBackground());
            setForeground(list.getSelectionForeground());
        } else {
            setBackground(list.getBackground());
            setForeground(list.getForeground());
        }

        Border outsideBorder = hasFocus ? UIManager.getBorder("List.focusCellHighlightBorder") : NO_FOCUS_BORDER;
        setBorder(BorderFactory.createCompoundBorder(outsideBorder, insideBorder));
        setComponentOrientation(list.getComponentOrientation());
        setEnabled(list.isEnabled());
        setFont(list.getFont());

        return this;
    }

    public void validate() {}
    public void invalidate() {}
    public void repaint() {}
    public void revalidate() {}
    public void repaint(long tm, int x, int y, int width, int height) {}
    public void repaint(Rectangle r) {}
}
